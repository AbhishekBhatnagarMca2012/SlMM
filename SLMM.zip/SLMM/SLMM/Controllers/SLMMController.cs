﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SLMM.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SLMM.Controllers
{
  
    [Controller]
    public class SLMMController : ControllerBase
    {
        private static int[] _position = new int[2] { 0, 0 };
        private static int[] _size = new int[2] { 10, 8 }; // Assume
        private static Direction _direction = Direction.North;
        private static Dictionary<SLMMAction, int> _waitTime = new Dictionary<SLMMAction, int>()
        {
            { SLMMAction.MoveForward,5 },
            { SLMMAction.MoveClockwise,2 },
            { SLMMAction.MoveAntiClockwise,2 }
        };

        private static Dictionary<SLMMAction, int> _directionValue = new Dictionary<SLMMAction, int>()
        {
            {SLMMAction.MoveAntiClockwise, 1 },
            {SLMMAction.MoveClockwise, -1 }
        };

      


        /// <summary>
        /// Single method to perform movement of SLMM
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>

        [HttpPost]
        [Route("ChangePosition")]
        public Response ChangePosition([FromBody]Request request)
        {
            try
            {
                if (ValidateRequest(request))
                {
                    //Thread.Sleep(_waitTime[request.action] * 1000);
                    if (request.action == SLMMAction.MoveClockwise || request.action == SLMMAction.MoveAntiClockwise)
                    {
                        ChangeDirection(_directionValue[request.action]);
                        return GenerateResponse("Direction Changed Successfully !!",SLMMStatus.Successful);
                    }
                    else
                    {
                        return MoveForward();
                    }
                }
                else
                {
                    return GenerateResponse("Error : InValid Request !!", SLMMStatus.Error);
                }
            }
            catch (Exception ex)
            { 
            // Exception Logging
            }
            return null;
        }

        private Response MoveForward()
        {
            bool IsMoved = false;
            switch (_direction)
            {
                case Direction.North:
                    if (_position[1] < _size[1] - 1)
                    {
                        _position[1]++;
                        IsMoved = true;
                    }
                    break;
                case Direction.East:
                    if (_position[0] < _size[0] - 1)
                    {
                        _position[0]++;
                        IsMoved = true;
                    }
                    break;
                case Direction.South:
                    if (_position[1] > 0)
                    {
                        _position[1]--;
                        IsMoved = true;
                    }
                    break;
                case Direction.West:
                    if (_position[0] > 0)
                    {
                        _position[0]--;
                        IsMoved = true;
                    }
                    break;
            }
            return GenerateResponse(IsMoved ? "SLMM Moved Successfully" : "SLMM unable to move out of garden area",
               IsMoved ? SLMMStatus.Successful:SLMMStatus.Error);
        }
        private Response GenerateResponse(string statusValue, SLMMStatus status)
        {
            return new Response()
            {
                CurrentPosition = _position,
                ResponseStatus = statusValue,
                MovingDirection = _direction.ToString(),
                Status = status.ToString()
            };
        }

        private void ChangeDirection(int value)
        {
            int directionId = (int)_direction + value;
            if (directionId < 0)
            {
                directionId = 3;
            }
            if (directionId > 3)
            {
                directionId = 0;
            }

            _direction = (Direction)directionId;
        }

        private bool ValidateRequest(Request request)
        {
            return request == null || 
                   request.action == SLMMAction.MoveAntiClockwise || 
                   request.action == SLMMAction.MoveClockwise || 
                   request.action == SLMMAction.MoveForward;
        }
    }
}
