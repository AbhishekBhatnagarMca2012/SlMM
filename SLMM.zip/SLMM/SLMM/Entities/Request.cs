﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLMM.Entities
{
    public class Request
    {
        public SLMMAction action { get; set; }
    }
}
