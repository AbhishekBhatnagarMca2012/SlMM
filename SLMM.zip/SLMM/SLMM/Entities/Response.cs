﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLMM.Entities
{
    public class Response
    {
        public string ResponseStatus { get; set; }
        public int[] CurrentPosition { get; set; }
        public string MovingDirection { get; set; }
        public string Status { get; set; }
    }
}
