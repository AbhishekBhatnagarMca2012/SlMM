﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLMM.Entities
{
    public enum Direction
    {
        East,
        North,
        West,
        South
    }

    public enum SLMMAction
    {
        MoveForward,
        MoveClockwise,
        MoveAntiClockwise
    }

    public enum SLMMStatus
    {
        Successful,
        Error
    }
}

